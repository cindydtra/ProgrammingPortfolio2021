import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Calculator extends PApplet {

/*////////////////////////////////////
 2020 Calculator for Programming 1
 Cindy Tra | November 2020
 ///////////////////////////////////*/

// Globals
Button[] numButtons = new Button[10];
Button[] opButtons = new Button[13];
String dVal, op;
boolean left;
float l, r, result;

public void setup() {
  
  dVal = "0";
  op = "";
  left = true;
  l = 0.0f;
  r = 0.0f;
  result = 0.0f;

  numButtons[0] = new Button(40, 430, 115, 55, "0", true);
  numButtons[1] = new Button(40, 370, 55, 55, "1", true);
  numButtons[2] = new Button(100, 370, 55, 55, "2", true);
  numButtons[3] = new Button(160, 370, 55, 55, "3", true);
  numButtons[4] = new Button(40, 310, 55, 55, "4", true);
  numButtons[5] = new Button(100, 310, 55, 55, "5", true);
  numButtons[6] = new Button(160, 310, 55, 55, "6", true);
  numButtons[7] = new Button(40, 250, 55, 55, "7", true);
  numButtons[8] = new Button(100, 250, 55, 55, "8", true);
  numButtons[9] = new Button(160, 250, 55, 55, "9", true);

  opButtons[0] = new Button(40, 190, 55, 55, "sin", false);
  opButtons[1] = new Button(100, 190, 55, 55, "cos", false);
  opButtons[2] = new Button(160, 190, 55, 55, "x²", false);
  opButtons[3] = new Button(160, 430, 55, 55, ".", false);
  opButtons[4] = new Button(220, 430, 55, 55, "=", false);
  opButtons[5] = new Button(220, 370, 55, 55, "+", false);
  opButtons[6] = new Button(220, 310, 55, 55, "-", false);
  opButtons[7] = new Button(220, 250, 55, 55, "x", false);
  opButtons[8] = new Button(220, 190, 55, 55, "÷", false);
  opButtons[9] = new Button(40, 130, 55, 55, "C", false);
  opButtons[10] = new Button(100, 130, 55, 55, "±", false);
  opButtons[11] = new Button(160, 130, 55, 55, "%", false);
  opButtons[12] = new Button(220, 130, 55, 55, "√", false);
}

public void draw() {
  background(127);
  fill(0xff00003D);
  rect(10, 10, 290, 490, 50);
  textSize(25);

  // Show Calculator Display
  updateDisplay();

  // Display and Hover Buttons
  for (int i=0; i<numButtons.length; i++) {
    numButtons[i].display();
    numButtons[i].hover();
  }
  for (int i=0; i<opButtons.length; i++) {
    opButtons[i].display();
    opButtons[i].hover();
  }
}

public void updateDisplay() {
  rectMode(CORNER);
  fill(0xff06254A);
  rect(40, 30, width-75, 80);

  fill(255);
  textAlign(RIGHT);

  // Render Scaling Text
  if (dVal.length()<13) {
    textSize(30);
  } else if (dVal.length()<14) {
    textSize(27);
  } else if (dVal.length()<15) {
    textSize(25);
  } else if (dVal.length()<17) {
    textSize(22);
  } else if (dVal.length()<19) {
    textSize(20);
  } else if (dVal.length()<21) {
    textSize(18);
  } else if (dVal.length()<23) {
    textSize(16);
  } else if (dVal.length()<25) {
    textSize(15);
  } else {
    textSize(13);
  }
  text(dVal, width-38, 85);
}

public void mouseReleased() {
  println("L:" + l + " R:" + r + " Op:" + op);
  println("Result:" + result + " Left:" + left);

  for (int i=0; i<numButtons.length; i++) {
    if (numButtons[i].hover && dVal.length()<20) {
      handleEvent(numButtons[i].val, true);
    }
  }

  for (int i=0; i<opButtons.length; i++) {
    if (opButtons[i].hover) {
      handleEvent(opButtons[i].val, false);
    }
  }
}

public void keyPressed() {
  println("KEY:" + key + " keyCode:" + keyCode);

  if (key == '0') {
    handleEvent("0", true);
  } else if (key == '1') {
    handleEvent("1", true);
  } else if (key == '2') {
    handleEvent("2", true);
  } else if (key == '3') {
    handleEvent("3", true);
  } else if (key == '4') {
    handleEvent("4", true);
  } else if (key == '5') {
    handleEvent("5", true);
  } else if (key == '6') {
    handleEvent("6", true);
  } else if (key == '7') {
    handleEvent("7", true);
  } else if (key == '8') {
    handleEvent("8", true);
  } else if (key == '9') {
    handleEvent("9", true);
  } else if (key == '+') {
    handleEvent("+", false);
  } else if (key == '-') {
    handleEvent("-", false);
  } else if (key == '*') {
    handleEvent("x", false);
  } else if (key == '/') {
    handleEvent("÷", false);
  } else if (key == '.') {
    handleEvent(".", false);
  } else if (key == 'C') {
    handleEvent("C", false);
  } else if (key == 10) {
    if (keyCode == ENTER || keyCode == RETURN) {
      handleEvent("=", false);
    }
  }
}

public String handleEvent(String val, boolean num) {
  if (left && num) { 
    if (dVal.equals("0")) {
      dVal = val;
      l = PApplet.parseFloat(dVal);
    } else {
      dVal += val;
      l = PApplet.parseFloat(dVal);
    }
  } else if (!left && num) { 
    if (dVal.equals("+") || dVal.equals("-") || dVal.equals("x") || dVal.equals("÷")) {
      dVal = val;
      r = PApplet.parseFloat(dVal);
    } else {
      dVal += val;
      r = PApplet.parseFloat(dVal);
    }
  } else if (val.equals("C")) {
    dVal = "0";
    op = "";
    left = true;
    l = 0.0f;
    r = 0.0f;
    result = 0.0f;
  } else if (val.equals("+")) {
    if (!left) {
      performCalc();
    } else {
      op = "+";
      left = false;
      dVal = "+";
    }
  } else if (val.equals("-")) {
    if (!left) {
      performCalc();
    } else {
      op = "-";
      left = false;
      dVal = "-";
    }
  } else if (val.equals("x")) {
    if (!left) {
      performCalc();
    } else {
      op = "x";
      left = false;
      dVal = "x";
    }
  } else if (val.equals("÷")) {
    if (!left) {
      performCalc();
    } else {
      op = "÷";
      left = false;
      dVal = "÷";
    }
  } else if (val.equals("±")) {
    if (left) {
      l *= -1;
      dVal = str(l);
    } else {
      r *= -1;
      dVal = str(r);
    }
  } else if (val.equals(".") && !dVal.contains(".")) {
    if (left) {
      dVal += (val);
      l = PApplet.parseFloat(dVal);
    } else {
      dVal += (val);
      r = PApplet.parseFloat(dVal);
    }
  } else if (val.equals("=")) {
    performCalc();
  } else if (val.equals("%")) {
    if (left) {
      l *= 0.1f;
      dVal = str(l);
    } else {
      r *= 0.1f;
      dVal = str(r);
    }
  } else if (val.equals("x²")) {
    if (left) {
      l = sq(l);
      dVal = str(l);
    } else {
      r = sq(r);
      dVal = str(r);
    }
  } else if (val.equals("√")) {
    if (left) {
      l = sqrt(l);
      dVal = str(l);
    } else {
      r = sqrt(r);
      dVal = str(r);
    }
  } else if (val.equals("sin")) {
    if (left) {
      l = sin(radians(l));
      dVal = str(l);
    } else {
      r = sin(radians(r));
      dVal = str(r);
    }
  } else if (val.equals("cos")) {
    if (left) {
      l = cos(radians(l));
      dVal = str(l);
    } else {
      r = cos(radians(r));
      dVal = str(r);
    }
  }
  return val;
}

public void performCalc() {
  if (op.equals("+")) {
    result = l + r;
  } else if (op.equals("-")) {
    result = l - r;
  } else if (op.equals("x")) {
    result = l * r;
  } else if (op.equals("÷")) {
    result = l / r;
  }
  l = result;
  dVal = str(result);
  left = true;
}
class Button {
  // Member Variables
  int x, y, w, h;
  String val;
  boolean hover, isNumber;
  int c1, c2, c3, c4, c5, c6;

  // Constructor
  Button(int tempX, int tempY, int tempW, int tempH, String tempVal, boolean isNumber) {
    x = tempX;
    y = tempY;
    w = tempW;
    h = tempH;
    val = tempVal;
    hover = false;
    c1 = 0xff0CA9F7;
    c2 = 0xff0066CC;
    c3 = 0xff009900;
    c4 = 0xff0DFF04;
    c5 = 0xff0056AB;
    c6 = 0xff004487;
    this.isNumber = isNumber;
  }

  // Display the Button
  public void display() {
    if (isNumber == true) { // number buttons
      if (hover) {
        fill (c1);
      } else {
        fill (c2);
      }
      //rectMode(CENTER);
      rect(x, y, w, h);
      fill(255);
      textAlign(CENTER);
      text(val, x+w/2, y+40);
    } else if (val.equals(".")) {
      if (hover) {
        fill (c1);
      } else {
        fill (c2);
      }
      //rectMode(CENTER);
      rect(x, y, w, h);
      fill(255);
      textAlign(CENTER);
      text(val, x+w/2, y+40);
    } else if (val.equals("C")) {
      if (hover) {
        fill (c5);
      } else {
        fill (c6);
      }
      //rectMode(CENTER);
      rect(x, y, w, h);
      fill(255);
      textAlign(CENTER);
      text(val, x+w/2, y+40);
    } else if (val.equals("±")) {
      if (hover) {
        fill (c5);
      } else {
        fill (c6);
      }
      //rectMode(CENTER);
      rect(x, y, w, h);
      fill(255);
      textAlign(CENTER);
      text(val, x+w/2, y+40);
    } else if (val.equals("%")) {
      if (hover) {
        fill (c5);
      } else {
        fill (c6);
      }
      //rectMode(CENTER);
      rect(x, y, w, h);
      fill(255);
      textAlign(CENTER);
      text(val, x+w/2, y+40);
    } else if (val.equals("√")) {
      if (hover) {
        fill (c5);
      } else {
        fill (c6);
      }
      //rectMode(CENTER);
      rect(x, y, w, h);
      fill(255);
      textAlign(CENTER);
      text(val, x+w/2, y+40);
    } 
    else { // non-number buttons
      if (hover) {
        fill (c4);
      } else {
        fill (c3);
      }
      //rectMode(CENTER);
      rect(x, y, w, h);
      fill(255);
      textAlign(CENTER);
      text(val, x+w/2, y+40);
    }
  }

  // Edge Detection
  public void hover() {
    hover = mouseX>x && mouseX<x+w && mouseY>y && mouseY<y+h;
  }
}
  public void settings() {  size (310, 510); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Calculator" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
